package com.example.ultraduperultimate;

public enum Direction {
    DOWN("D"), LEFT("L"), RIGHT("R"), UP("U");

    Direction(String string) {
    }
}
